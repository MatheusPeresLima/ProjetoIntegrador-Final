export interface PropsMaskedValue {
  value: any
  pattern: any
}
