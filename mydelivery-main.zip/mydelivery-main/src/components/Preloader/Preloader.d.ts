export interface PropsPreloader {
  active: boolean
}
